import {combineReducers, createStore} from "redux";
import ProfileReducer from "./userInfo";


const rootReducer = combineReducers({
    profileReducer:ProfileReducer
})

export const store = createStore(rootReducer)