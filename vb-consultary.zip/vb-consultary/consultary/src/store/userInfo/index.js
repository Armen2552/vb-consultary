

const initialState = {
    profile: {
        bDay: "",
        create_at: "",
        dateOfExpiry: "",
        dateOfIssue: "",
        email: "",
        firstName: "",
        gender: "Mr.",
        id: "",
        imagePath: "",
        lastName: "",
        mobileNo: "",
        nationality: "",
        passport: "",
        pdfPath: "",
        placeOfIssue: "",
        userMessage: "",
        vacancies: ""
    }
}


 const ProfileReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'ADD_PROFILE_INFO': {
            return {...state, profile:{...state.profile, ...action.payload}}
        }
        // case profileActions.MANAGE_USER_PROFILE_IMAGE: {
        //     console.log('MANAGE_USER_PROFILE_IMAGE')
        //     console.log(action)
        //     return {...state,profile:{...state.profile, profileImage:action.payload}}
        // }


        // IMPORTANT
        default: {
            return state
        }
    }

}
export default  ProfileReducer
