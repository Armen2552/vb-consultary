import { useState, useContext, createContext } from "react";
import emptyUser from './assets/images/people.svg'

const AppContext = createContext()

const AppProvider = ({ children }) => {

    const [token, setToken] = useState(false)
    const [cookie,setCookie] = useState(true)
    const [seeImage, setSeeImage] = useState(emptyUser);
    const [newsSub,setNewSub] = useState({})
    const [news,setNews] = useState([])

    const [profile, setProfile] = useState({
        bDay: "",
        create_at: "",
        dateOfExpiry: "",
        dateOfIssue: "",
        email: "",
        firstName: "",
        gender: "Mr.",
        id: "",
        imagePath: "",
        lastName: "",
        mobileNo: "",
        nationality: "",
        passport: "",
        pdfPath: "",
        placeOfIssue: "",
        userMessage: "",
        vacancies: ""
    })

    return <AppContext.Provider value={{
        profile,
        setProfile,
        token,
        setToken,
        cookie,
        setCookie,
        seeImage,
        setSeeImage,
        newsSub,
        setNewSub,
        news,
        setNews

    }}>
        {children}
    </AppContext.Provider>
}


const useGlobalContext = () => {
    return useContext(AppContext)
}


export  { AppProvider, useGlobalContext }