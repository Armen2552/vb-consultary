export const ROUTER_NAMES = {
    HOME: '/*',
    ABOUT_US: '/about-us',
    VACANCIES: '/vacancies',
    CONTACT_US: '/contact-us',
    PRIVACY: '/privacy',
    FAQS: '/faqs',
    TERMS:'/terms',
    PROFILE: '/profile',
    APPLY: '/apply',
    POLAND: '/poland',
    CZEHREPUBLIC: '/CzehRepublic',
    UAE: '/uae',
    RUSSIA:'/Russia',
    ROMANIA:'/Romania',
    NEWS:'/news',
    NEWS_SUB:'/news-Sub'

}

export const ApiUrl = 'http://admin.vbkconsultancy.in/'
// export const ApiUrl = 'http://localhost:5000/'