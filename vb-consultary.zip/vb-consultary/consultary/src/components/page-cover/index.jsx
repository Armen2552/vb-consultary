import React from "react";
import "./style.scss"


export const PageCover = (props)=>{
    return <div className="P-cover" style={{backgroundImage: `url('${props.image}')`}}>
        <div className="P-cover-title G-flex G-center">
            <p>{props.title}</p>
        </div>
    </div>
}