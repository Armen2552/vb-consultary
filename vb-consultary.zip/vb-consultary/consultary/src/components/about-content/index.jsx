import React from "react";
import "./style.scss"

export const AboutContent  = (props)=>{

    return <div className="P-about-main">
        <div className="P-about-content-first G-flex G-align-center G-justify-between">
            <img className="P-first" src={props.image1} alt="cover"/>
            <img className="P-second" src={props.image11} alt="cover"/>
            <div className="P-description">
                <h2>{props.title1}</h2>
                <p>{props.description1}</p>
            </div>
        </div>
        <div className="P-about-content-second G-flex G-align-center G-justify-between">
            <div className="P-description">
                <h2>{props.title2}</h2>
                <p>{props.description2}</p>
            </div>
            <img className="P-first" src={props.image2} alt="cover2"/>
            <img className="P-second"  src={props.image21} alt="cover2"/>
        </div>
    </div>
}