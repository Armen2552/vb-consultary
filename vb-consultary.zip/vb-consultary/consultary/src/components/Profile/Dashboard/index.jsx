import React, {useState} from "react";
import "./style.scss"
import Logo from "../../../assets/images/logo.svg"
import {NavLink, Link, useNavigate} from "react-router-dom";
import {ROUTER_NAMES} from "../../../routers";
import {useGlobalContext} from '../../../context';


export const ProfileDashboard = () => {
    const {setToken} = useGlobalContext()
    const navigate = useNavigate()

    const [modal, setModal] = useState(false)

    const clickModal = (a) => {
        setModal(a)
    }

    const clickLogout = () => {
        localStorage.removeItem("id")
        setToken("")
        navigate(ROUTER_NAMES.HOME)
        window.location.reload()
    }


    const [map] = useState([
        {
            title: "Profile",
            path: "/profile",
            img: "icon-single"
        },
        {
            title: "Apply",
            path: "/apply",
            img: "icon-settings"
        }
    ])


    return <div className="P-profile-dashboard G-flex G-flex-column G-align-center">
        <Link to={ROUTER_NAMES.HOME}>
            <div className="P-dashboard-logo G-flex G-flex-column">
                <img src={Logo} alt="Logo"/>
                <p>VBK CONSULTANCY</p>
            </div>
        </Link>
        <ul>
            {map.map((elem, index) => {
                return <li className="P-menu-main G-flex G-align-center" key={index}>
                    <NavLink className="G-flex G-justify-between" to={elem.path}>
                        <i className={elem.img}/>
                        {elem.title}
                    </NavLink>
                </li>
            })}
            {map.map((elem, index) => {
                return <li className="P-menu-mobile G-flex G-align-center" key={index}>
                    <NavLink className="G-flex G-justify-between" to={elem.path}>
                        <i className={elem.img}/>
                    </NavLink>
                </li>
            })}
            <li>
                <button onClick={() => clickModal(true)} className="G-flex G-justify-between">
                    <i className="icon-logout"/>
                    <span>Logout</span>
                </button>
            </li>
        </ul>
        {modal ? <div className="P-logout-modal">
            <div className="P-modal-content">
                <h3>Do you want to logout?</h3>
                <div className="P-modal-actions G-flex">
                    <button onClick={clickLogout}>Yes</button>
                    <button onClick={() => clickModal(false)}>No</button>
                </div>
            </div>
        </div> : null}
    </div>
}