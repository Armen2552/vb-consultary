import React, {useEffect} from "react";
import "./style.scss"
// import coverImage from "../../../assets/images/profilecover.svg"
// import {useSelector} from "react-redux";
import {useGlobalContext} from '../../../context';
import {UserInfo} from "../../../platform/api";
import {ApiUrl} from "../../../routers";


export const ProfileSection = () => {
    // const profile = useSelector(state => state.profileReducer.profile)
    const {profile, seeImage, setProfile, setSeeImage} = useGlobalContext();

    useEffect(() => {
        let x = localStorage.getItem('id')
        if (x) {
            UserInfoGet(x)
        }
    }, [])

    const UserInfoGet = async (userId) => {
        const result = await UserInfo({id: userId})
        if (result) {
            setProfile(result.data)
            if (result.data.imagePath) {
                setSeeImage(ApiUrl + result.data.imagePath.slice(6))
            }
        }
    }

    return <div className="P-main">
        <div className="G-profile-container">
            <div className="P-profile-cover G-flex">
                <div className="P-profile-image">
                    <img src={seeImage} className="P-image" alt='pers'/>
                    <p>{profile.nationality ? profile.nationality : '--'}</p>
                </div>
                <div className="P-profile-name">
                    <h2>{profile.firstName ? profile.firstName : '--'} {profile.lastName ? profile.lastName : '--'}</h2>
                    <p>{profile.email ? profile.email : '--'}</p>
                </div>
            </div>
            <span/>
            <div className="P-main-title">
                <h2>Phone number(WhatsApp): </h2>
                <p>{profile.mobileNo ? profile.mobileNo : '--'}</p>
                <h2>Date of Birth</h2>
                <p>{profile.bDay ? profile.bDay.slice(0, 10) : '--'}</p>
                <div className="P-passport-main G-flex">
                    <div>
                        <h2>Passport</h2>
                        <p>{profile.passport ? profile.passport : '--'}</p>
                    </div>
                    <div className="P-passport-second">
                        <span />
                        <div className="G-flex G-justify-evenly">
                            <div>
                                <h2>Date of Issue:</h2>
                                <p>{profile.dateOfIssue ? profile.dateOfIssue.slice(0, 10) : '--'}</p>
                            </div>
                            <div>
                                <h2>Date of Expiry:</h2>
                                <p>{profile.dateOfExpiry ? profile.dateOfExpiry.slice(0, 10) : '--'}</p>
                            </div>
                            <div>
                                <h2>Place of Issue:</h2>
                                <p>{profile.placeOfIssue ? profile.placeOfIssue : '--'}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <h2>Vacancies</h2>
                <p>{profile.vacancies ? profile.vacancies : '--'}</p>
                <h2>Your Message</h2>
                <p>
                    {profile.userMessage ? profile.userMessage : '--'}
                </p>
                <h2>Your CV</h2>
                <h3>{profile.pdfPath? profile.pdfPath : '--'} </h3>
            </div>
        </div>
    </div>
}