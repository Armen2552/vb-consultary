import React from "react";
import "./style.scss"
// import cover from "../../../assets/images/section-cover.jpg"
import {Link} from "react-router-dom";
import {ROUTER_NAMES} from "../../../routers";
import {useGlobalContext} from "../../../context";
import Ring from "../../../assets/images/ring.png"


export const ProfileMap = (props)=>{

    const {profile,seeImage} = useGlobalContext();



    return <div className="P-profile-map">
        <div className="G-profile-container G-flex G-justify-between">
            <div className="P-profile-map-main">
                <h2>{props.description}</h2>
                <p><Link to={ROUTER_NAMES.HOME}>Home></Link>{props.description}</p>
            </div>
            <div className="P-profile-map-description G-flex G-align-center">
                <div className="P-notification G-flex G-align-center">
                    <img src={Ring} alt="ring"/>
                    <p>Notifications</p>
                </div>
                <div className="P-description G-flex G-align-center">
                    <img src={seeImage} alt='pers' />
                    <p>{profile.firstName? profile.firstName : '--'} {profile.lastName? profile.lastName : '--'}</p>
                </div>
            </div>
        </div>
    </div>
}