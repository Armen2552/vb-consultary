    import React, {useEffect, useState} from "react";
    import "./style.scss"
    import Person from "../../../assets/images/person.svg"
    import Massage from "../../../assets/images/Vectormassage.svg"
    import Date from "../../../assets/images/date.svg"
    import Country from "../../../assets/images/country.svg"
    import Passport from "../../../assets/images/passport.svg"
    import Photoplus from "../../../assets/images/photoplus.png"
    import Phone from "../../../assets/images/phone.svg"
    import Vacancies from "../../../assets/images/vacancies-chose.svg"
    import {UserInfo, UserInfoAll, UserImage, UserResume, DeactiveAccount} from "../../../platform/api";
    import {useGlobalContext} from '../../../context';
    import {ApiUrl, ROUTER_NAMES} from "../../../routers";
    import Pdf from "../../../assets/images/pdf.png"
    import {useNavigate} from "react-router-dom";
    import emptyUser from '../../../assets/images/people.svg'


    export const Apply = ()=>{
        const {profile, setProfile,seeImage, setSeeImage,setToken} = useGlobalContext();
        const [resume, setResume] = useState('');
        const [image, setImage] = useState()
        const [modal,setModal] = useState(false)
        const [other,setOther] = useState(false)
        const navigate = useNavigate()
        const [save,SetSave] = useState(false)
        const [mandatory,SetMandatory] = useState(true)


        // const [user,setUser] = useState({
        //     bDay: "",
        //     create_at: "",
        //     dateOfExpiry: "",
        //     dateOfIssue: "",
        //     email: "",
        //     firstName: "",
        //     gender: "Mr.",
        //     id: "",
        //     imagePath: "",
        //     lastName: "",
        //     mobileNo: "",
        //     nationality: "",
        //     passport: "",
        //     pdfPath: "",
        //     placeOfIssue: "",
        //     userMessage: "",
        //     vacancies: ""
        // })

        const [errors, setErrors] = useState({
            imagePath: "",
            bDay: "",
            dateOfExpiry: "",
            dateOfIssue: "",
            firstName: "",
            lastName: "",
            mobileNo: "",
            nationality: "",
            passport: "",
            placeOfIssue: "",
            vacancies: "",
            pdfPath: ""
        })


        useEffect(()=>{
            let x = localStorage.getItem('id')
            if (x) {
                UserInfoGet(x)
                // window.location.reload()
            //
            //     fetch("http://localhost:5000/send_info_to_apply",{
            //         method:"POST",
            //         headers:{
            //             "Content-Type":"application/json"
            //         },
            //         body:JSON.stringify({id:item})
            //
            //     })
            //         .then(response=>response.text())
            //         .then(result=>console.log((result)))
            }
        },[])

        // useEffect(()=>{
        //     console.log(id)
        // },[id])

        const clickModal = (a)=>{
            setModal(a)
        }

        const clickLogout = ()=>{
            Deactive()
            // setToken("")
            // navigate(ROUTER_NAMES.HOME)
            // // localStorage.removeItem("id")
            // window.location.reload()
        }


        const UploadImage = (e) => {
            const reader = new FileReader();
            reader.onload = () => {
                if (reader.readyState == 2) {
                    setSeeImage(reader.result)
                    setImage(e.target.files[0])
                }
            }
            reader.readAsDataURL(e.target.files[0]);
            setErrors({...errors,imagePath: ""})
        }

        const UploadFile = (e) => {
            const reader = new FileReader();
            reader.onload = () => {
                if (reader.readyState == 2) {
                    setResume(e.target.files[0])
                }
            }
            reader.readAsDataURL(e.target.files[0]);
            setErrors({...errors,pdfPath: ""})
        }


        const InfoChange = (e)=>{
            if(e.target.value==="Other"){
                setOther(true)
            }
            setProfile({...profile, [e.target.name]: e.target.value})
            setErrors({...errors, [e.target.name]: ""})
        }


        const validation =()=>{
            let isValidate = true
            const errors = {
                imagePath: "",
                bDay: "",
                dateOfExpiry: "",
                dateOfIssue: "",
                firstName: "",
                lastName: "",
                mobileNo: "",
                nationality: "",
                passport: "",
                placeOfIssue: "",
                vacancies: "",
                pdfPath: ""
            }

            if(!profile.firstName){
                isValidate = false
                errors.firstName = 'Fill the field'
            }
            if(!profile.lastName){
                isValidate = false
                errors.lastName = 'Fill the field'
            }
            if(!profile.vacancies){
                isValidate = false
                errors.vacancies = 'Fill the field'
            }
            if(!seeImage || seeImage===emptyUser){
                isValidate = false
                errors.imagePath = 'Fill the field'
            }
            if(!resume && !profile.pdfPath){
                isValidate = false
                errors.pdfPath = 'Fill the field'
            }
            if(!profile.bDay){
                isValidate = false
                errors.bDay = 'Fill the field'
            }
            if(!profile.dateOfExpiry){
                isValidate = false
                errors.dateOfExpiry = 'Fill the field'
            }
            if(!profile.dateOfIssue){
                isValidate = false
                errors.dateOfIssue = 'Fill the field'
            }
            if(!profile.mobileNo){
                isValidate = false
                errors.mobileNo = 'Fill the field'
            }
            if(!profile.nationality){
                isValidate = false
                errors.nationality = 'Fill the field'
            }
            if(!profile.passport){
                isValidate = false
                errors.passport = 'Fill the field'
            }
            if(!profile.placeOfIssue){
                isValidate = false
                errors.placeOfIssue = 'Fill the field'
            }
            if(!profile.vacancies){
                isValidate = false
                errors.vacancies = 'Fill the field'
            }
            SetMandatory(isValidate)
            setErrors(errors)
            return isValidate
        }


        const genderclick = (a) => {
            setProfile({...profile, gender: a})
        }

        const UserInfoGet = async (userId)=>{
                const result = await UserInfo({id:userId})
                if(result){
                    setProfile(result.data)
                    if(result.data.imagePath) {
                        setSeeImage(ApiUrl+result.data.imagePath.slice(6))
                    }
                }else{
                    console.log('errror')
                }
        }

        const UserImageUpload = async (e) => {
            let form_data = new FormData();
            form_data.append("fileData", image)
            form_data.append("id",e)
            const result = await UserImage(form_data)
        }

        const UserResumeUpload = async (e) => {
            let form_data = new FormData();
            form_data.append("resumeData", resume)
            form_data.append("id",e)
            const result = await UserResume(form_data)
        }

        const Deactive = async () =>{
            let x = localStorage.getItem('id')
            const result = await DeactiveAccount({id:x})
                if(result){
                    setToken("")
                    localStorage.removeItem("id")
                    navigate(ROUTER_NAMES.HOME)
                    window.location.reload()
                }
        }

        const SavePass = ()=>{
            SetSave(true)
            setTimeout(()=>{
                SetSave(false)
            },1500)
        }

        const UserInfoTake = async () => {
            if(validation()) {
                const result = await UserInfoAll(profile)
                if (result) {
                    let id = result.data;
                    UserImageUpload(id)
                    UserResumeUpload(id)
                    SavePass()
                }
            }
        }

        return <div className="P-apply G-flex">
            <div className="P-apply-title">
                <div className="P-gender G-flex">
                    <p>Title</p>
                    <button
                        onClick={()=>genderclick("Mr.")}
                        className={`P-gender-mr ${profile.gender==="Mr."? 'P-gender-active' : null}`}>Mr.</button>
                    <button
                        onClick={()=>genderclick("Ms.")}
                        className={`P-gender-mr ${profile.gender==="Ms."? 'P-gender-active' : null}`}>Mrs.</button>
                </div>
                <div className="P-apply-form G-flex G-flex-wrap G-justify-between">
                    <div className="P-input">
                        <p>First Name *</p>
                        <input
                            className={errors.firstName? "P-apply-error" : null}
                            onChange={InfoChange}
                            name="firstName"
                            type="text"
                            defaultValue={profile.firstName}/>
                        <img src={Person} alt="person"/>
                    </div>
                    <div className="P-input">
                        <p>Last Name *</p>
                        <input
                            className={errors.lastName? "P-apply-error" : null}
                            onChange={InfoChange}
                            name="lastName"
                            type="text"
                            defaultValue={profile.lastName}/>
                        <img src={Person} alt="person"/>
                    </div>
                    <div className="P-input">
                        <p>Email Address *</p>
                        <input
                            onChange={InfoChange}
                            name="email"
                            type="text"
                            defaultValue={profile.email}
                            disabled/>
                        <img src={Massage} alt="person"/>
                    </div>
                    <div className="P-input">
                        <p>Phone Number(WhatsApp) *</p>
                        <input
                            className={errors.mobileNo? "P-apply-error" : null}
                            onChange={InfoChange}
                            name="mobileNo"
                            type="tel"
                            defaultValue={profile.mobileNo}/>
                        <img src={Phone} alt="person"/>
                    </div>
                    <div className="P-input">
                        <p>Date of Birth *</p>
                        <input
                            className={errors.bDay? "P-apply-error" : null}
                            onChange={InfoChange}
                            name="bDay"
                            type="date"
                            defaultValue={profile.bDay? profile.bDay.slice(0, 10) : profile.bDay}/>
                        <img src={Date} alt="person"/>
                    </div>
                    <div className="P-input">
                        <p>Nationality *</p>
                        <input
                            className={errors.nationality? "P-apply-error" : null}
                            required={true}
                            onChange={InfoChange}
                            name="nationality"
                            type="text"
                            defaultValue={profile.nationality}/>
                        <img src={Country} alt="person"/>
                    </div>
                    <div className="P-input">
                        <p>Passport *</p>
                        <input
                            className={errors.passport? "P-apply-error" : null}
                            onChange={InfoChange}
                            name="passport"
                            type="text"
                            defaultValue={profile.passport}/>
                        <img src={Passport} alt="person"/>
                    </div>
                    <div className="P-apply-date-experience G-flex G-align-center G-justify-between">
                        <div className="P-input">
                            <p>Date of Issue*</p>
                            <input
                                className={errors.dateOfIssue? "P-apply-error" : null}
                                onChange={InfoChange}
                                name="dateOfIssue"
                                type="date"
                                defaultValue={profile.dateOfIssue? profile.dateOfIssue.slice(0, 10) : profile.dateOfIssue}/>
                        </div>
                        <div className="P-input">
                            <p>Date of Expiry*</p>
                            <input
                                className={errors.dateOfExpiry? "P-apply-error" : null}
                                onChange={InfoChange}
                                name="dateOfExpiry"
                                type="date"
                                defaultValue={profile.dateOfExpiry? profile.dateOfExpiry.slice(0, 10) : profile.dateOfExpiry}/>
                        </div>
                        <div className="P-input">
                            <p>Place of Issue*</p>
                            <input
                                className={errors.placeOfIssue? "P-apply-error" : null}
                                onChange={InfoChange}
                                name="placeOfIssue"
                                type="text"
                                defaultValue={profile.placeOfIssue}/>
                        </div>
                    </div>
                    <div className={`P-apply-vacancies G-flex G-justify-between G-align-center ${errors.vacancies? "P-vacancies-error"  : null}`}>
                        <div className="P-title G-flex G-align-center">
                            <img src={Vacancies} alt="Vacancies"/>
                    </div>
                        {!other? <select value={profile.vacancies} onChange={InfoChange} name="vacancies">
                            <option disabled={true} value="All-vacancies">All vacancies</option>
                            <option value="Construction">Construction</option>
                            <option value="Agricultural">Agricultural</option>
                            <option value="Catering">Catering</option>
                            <option value="Logistics">Logistics</option>
                            <option value="Housekeeping">Housekeeping</option>
                            <option value="Administration-management">Administration Management</option>
                            <option value="Customer-service">Customer Service</option>
                            <option value="Other">Other</option>
                        </select> : <input onChange={InfoChange} name="vacancies" type="text" autoFocus={true}/>}
                    </div>
                    <div className="P-your-massage">
                        <p>Your Message</p>
                        <textarea
                            onChange={InfoChange}
                            placeholder="Type here ..."
                            name="userMessage"
                            cols="30"
                            rows="10"
                            defaultValue={profile.userMessage}/>
                    </div>
                    <div className="P-upload-cv">
                        <p>Please Upload Your CV *</p>
                        <div className={errors.pdfPath? "P-pdf-error" : null}>
                            <input type="file" onChange={UploadFile}/>
                            <div className="G-flex">
                                <img src={Pdf} alt="PDF"/>
                                {resume.name? <h4>{resume.name}</h4> : null}
                                {profile.pdfPath? <h4>{profile.pdfPath}</h4> : null}
                            </div>
                        </div>
                    </div>
                    <div className="P-save G-flex G-justify-end G-align-start">
                        {save? <p>Done</p> : null }
                        {!mandatory? <p className="P-save-error">Fill in all the mandatory fields</p> : null}
                        <button onClick={UserInfoTake}>Save changes</button>
                    </div>
                    <span />
                    <h3  onClick={()=>clickModal(true)}>Deactivate account.</h3>
                </div>
            </div>
            <div className="P-apply-img">
                <img src={seeImage} alt="user"
                    className={`P-img ${errors.imagePath? "P-img-error" : null}`}
                    // style={{backgroundImage:`url('${seeImage}')`}}
                />
                <div className="P-upload">
                    <label>
                        <input
                            onChange={UploadImage}
                            type="file"/>
                        <div className="P-upload-img">
                            <img src={Photoplus} alt="Apparat"/>
                        </div>
                    </label>
                </div>
                <p>Ideal size : 500 * 500px</p>
                <p>Format : PNG or JPG</p>
                <p>Max weight : 4 mb</p>
            </div>
            {modal?<div className="P-logout-modal">
                <div className="P-modal-content">
                    <h3>Do you want to deactive Account?</h3>
                    <div className="P-modal-actions G-flex">
                        <button onClick={clickLogout}>Yes</button>
                        <button onClick={()=>clickModal(false)}>No</button>
                    </div>
                </div>
            </div> : null}
        </div>
    }