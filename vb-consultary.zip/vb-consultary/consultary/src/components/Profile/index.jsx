import React, {useEffect} from "react";
import {ProfileDashboard} from "./Dashboard";
import {ProfileMap} from "./Map";
import "../../assets/icon/style.css"
import "./style.scss"
import {ProfileSection} from "./Section";
import Footer from "../footer";
// import {Route, Routes} from "react-router-dom";
// import {ROUTER_NAMES} from "../../routers";
import {useLocation} from "react-router-dom";
import {Apply} from "./apply";




export const Profile = ()=>{
    const location = useLocation()

    useEffect(()=>{
        document.body.style.overflowY = "scroll"
    },[])


    return <>
        <div className="G-flex">
            <ProfileDashboard />
            <div className="P-profile-main">
                {location.pathname==='/profile'? <ProfileMap description={"Profile"}/> : null}
                {location.pathname==='/apply'? <ProfileMap description={"Apply"}/> : null}
                {location.pathname==='/profile'? <ProfileSection /> : null}
                {location.pathname==='/apply'? <Apply /> : null}
            </div>
        </div>
        <Footer />
    </>
}