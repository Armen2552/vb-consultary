import React, {useState} from "react";
import "../style.scss"
import {ForgotPassword} from "../../../../platform/api";
import {isEmail} from "../../../../utils/utils";
import {ROUTER_NAMES} from "../../../../routers";
import {Link} from "react-router-dom";
import Gif from "../../../../assets/images/forgotaccept.gif"


export const Forgot = () => {
    const [forget, setForget] = useState(true)


    const [email, setEmail] = useState({
        email: "",
    })

    const [error, setError] = useState({
        email: "",
    })

    const handleChange = (e) => {
        setEmail({...email, email: e.target.value})
        setError({...error, email: ""})
    }

    const validation = () => {
        let isValidate = true

        const error = {
            email: "",
        }

        if (!email.email) {
            isValidate = false
            error.email = "Fill the email field"
        } else if (email.email && !isEmail(email.email)) {
            isValidate = false
            error.email = 'Incorrect email address'
        }

        setError(error)

        return isValidate

    }

    const restorePassword = async () => {
        if (validation()) {
            const result = await ForgotPassword(email)
            if (result.data && result.data !== "Invalid Email") {
                setForget(false)
                console.log(result.data)
            } else if (result.data === "Invalid Email") {
                setError({...error, email: "Invalid Email"})
            } else {
                console.log('errror')
            }
        }
    }


    return <div className="P-sign-up-place">
        {forget ? <div className="P-forgot-password">
                <p>To reset your password, enter the email address you use to sign in to VBK Consultancy</p>
                <div>
                    <p>Email *</p>
                    <label className={error.email ? 'P-error' : null}>
                        <input onChange={handleChange} type="text"/>
                        {error.email ? <p>{error.email}</p> : null}
                    </label>
                </div>
                <button onClick={restorePassword}>Send Reset Link</button>
            </div> :
            <div className="P-password-link">
                <img src={Gif} alt="Gif"/>
                <h2>Password Link Sent </h2>
                <p>Please check your <span>{email.email}</span></p>
                <span className="P-line"/>
                <h3>Unsure if that email address was correct? <Link to={ROUTER_NAMES.FAQS}>We can help.</Link></h3>
            </div>}
    </div>
}