import React, {useState} from "react";
import Slider from "react-slick"
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./style.scss"
import {Link} from "react-router-dom";
import LatestCover1 from "../../assets/images/Rectangle 37.jpg"
import LatestCover2 from "../../assets/images/Rectangle 38.jpg"
import LatestCover3 from "../../assets/images/Rectangle 39.jpg"
import {ROUTER_NAMES} from "../../routers";

const LatestNews = () => {

    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 1,

        responsive: [
            {
                breakpoint: 1290,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    // autoplay: true,
                    // autoplaySpeed: 2000,
                    dots: false
                }
            },
            {
                breakpoint: 1150,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                    // autoplay: true,
                    // autoplaySpeed: 2000,
                    dots: false
                }
            },
            {
                breakpoint: 740,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true,
                    // autoplay: true,
                    // autoplaySpeed: 2000,
                    initialSlide: 1
                }
            },
            // {
            //     breakpoint: 480,
            //     settings: {
            //         slidesToShow: 1,
            //         slidesToScroll: 1,
            //         infinite: true,
            //         autoplay: true,
            //         autoplaySpeed: 2000,
            //
            //     }
            // }
        ]
    }





    const [news] = useState([
        {
            img: LatestCover1,
            description: 'How to Learn Faster and Remember',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '6 June 2022'
        },
        {
            img: LatestCover2,
            description: 'Free Online Courses from Top Universities',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '25 May 2022'
        },
        {
            img: LatestCover3,
            description: 'Learn Exactly How I Improved Education',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '20 May 2022'
        }
    ])


    return <div>
        <div className="P-latest-news">
            <div className="G-container">
                <h2>Latest News</h2>
                {/*<div className="G-flex G-justify-between">*/}
                {/*    {news.map((elem, index) => {*/}
                {/*        return <div key={index} className="P-latest-box">*/}
                {/*            <div className="P-latest-img" style={{backgroundImage: `url('${elem.img}')`}}/>*/}
                {/*            <div className="P-latest-box-title">*/}
                {/*                <h3>{elem.description}</h3>*/}
                {/*                <h4>{elem.title}</h4>*/}
                {/*                <span>READ MORE</span>*/}
                {/*                <p>{elem.date}</p>*/}
                {/*            </div>*/}
                {/*        </div>*/}
                {/*    })}*/}
                {/*</div>*/}
                <Slider {...settings}>
                    {news.map((elem, index) => {
                        return <div key={index}>
                            <div className="P-latest-box">
                                <div className="P-latest-img" style={{backgroundImage: `url('${elem.img}')`}}/>
                                <div className="P-latest-box-title">
                                    <h3>{elem.description}</h3>
                                    <h4>{elem.title}</h4>
                                    <span>READ MORE</span>
                                    <p>{elem.date}</p>
                                </div>
                            </div>
                        </div>
                    })}
                </Slider>
                <Link to={ROUTER_NAMES.NEWS}><button className="G-button">See More</button></Link>
            </div>
        </div>
    </div>
}

export default LatestNews