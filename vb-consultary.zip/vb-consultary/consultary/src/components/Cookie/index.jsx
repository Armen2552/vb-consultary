import React from "react";
import "./style.scss"
import CookieImg from "../../assets/images/cookie.png"
import {Link} from "react-router-dom";
import {ROUTER_NAMES} from "../../routers";


export const Cookie = (props)=>{


    return <div className="P-cookie G-flex G-justify-center G-align-center">
        <img src={CookieImg} alt="Cookie"/>
        <span />
        <p>We care about your data, and we'd love to use cookies to make your experience better. <Link to={ROUTER_NAMES.FAQS}>Learn more.</Link></p>
        <button onClick={props.closeCookie}>Accept</button>
    </div>
}