import React, {useEffect} from 'react'
import GuestPages from "../guest-pages";
// import AdminPages from "../admin-pages";



const AppComponent = () => {

    // const [token, setUserToken] = useState('')
    //
    // useEffect(() => {
    //     let x = localStorage.getItem('token_data')
    //     if (x) {
    //         setUserToken(x)
    //     }
    // }, [])
    //
    // return token? <AdminPages/> : <GuestPages/>
     return <>
          <GuestPages />
          </>
}
export default AppComponent