import React from "react";
import {Profile} from "../Profile";
import "../../assets/icon/style.css"

const AdminPages = ()=>{
    //  routes routes  for admin pages
    return <Profile />
}

export default AdminPages