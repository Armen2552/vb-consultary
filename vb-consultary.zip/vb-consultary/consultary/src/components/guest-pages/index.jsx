import React from "react";
import Header from "../header";
import {Route, Routes} from "react-router-dom";
import {ROUTER_NAMES} from "../../routers";
import Main from "../../pages/main-page";
import {About} from "../../pages/about-us";
import Footer from "../footer";
import {Privacy} from "../../pages/Privacy";
import {Terms} from "../../pages/Terms";
import {Contact} from "../../pages/contact-us";
import {Help} from "../../pages/Help-center";
// import AppComponent from "../app-component";
import {Poland} from "../../pages/vacancies-poland";


const GuestPages = () => {
    return <>
        <Header/>
        {/*<Main />*/}
        <Routes>
                {/*<Route path={ROUTER_NAMES.PROFILE} element={<AdminPages />} />*/}
                {/*<Route path={ROUTER_NAMES.APPLY} element={<AdminPages />} />*/}
                <Route path={ROUTER_NAMES.HOME} element={<Main />} />
                <Route path={ROUTER_NAMES.ABOUT_US} element={<About />} />
                <Route path={ROUTER_NAMES.CONTACT_US} element={<Contact />} />
                <Route path={ROUTER_NAMES.PRIVACY} element={<Privacy />} />
                <Route path={ROUTER_NAMES.FAQS} element={<Help />} />
                <Route path={ROUTER_NAMES.TERMS} element={<Terms />} />
                <Route path={ROUTER_NAMES.POLAND} element={<Poland />} />
        </Routes>
        <Footer/>
    </>
}
export default GuestPages