import React, {useState} from "react";
import "./style.scss"

export const HelpContent = (props)=>{

    const [openclose,setOpenclose] = useState(false)

    const TextClick = ()=>{
        setOpenclose(!openclose)
    }

    return <div className="P-help-description-main">
        <div className="P-help-description G-flex G-justify-between G-align-center" onClick={TextClick}>
            <h4>{props.description}</h4>
            <span />
        </div>
        {openclose?<p>{props.description2}</p> : null}
    </div>
}