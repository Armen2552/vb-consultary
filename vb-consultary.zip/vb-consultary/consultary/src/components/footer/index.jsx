import React, {useState} from "react";
import {Link} from "react-router-dom";
import "./style.scss"
import LogoFooter from "../../assets/images/logo.svg"
import Tel from "../../assets/images/tel.png"
import Massage from "../../assets/images/massage.png"
import {ROUTER_NAMES} from "../../routers";


const Footer = () => {

    const [list1] = useState([
        {
            description: "Home",
            path: "/"
        },
        {
            description: "About Us",
            path: "/about-us"
        },
        {
            description: "News",
            path: "/news"
        },

    ])

    const [list2] = useState([
        {
            description: "Privacy",
            path: "/privacy"
        },
        {
            description: "FAQ",
            path: "/faqs"
        },
        {
            description: "Terms",
            path: "/terms"
        },

    ])


    return <div className="P-main-footer">
        <div className="P-second-footer">
            <div className="G-container G-flex G-justify-between">
                <Link to={ROUTER_NAMES.HOME}>
                    <div className="P-footer-logo G-flex G-center G-flex-column">
                        <img src={LogoFooter} alt="Logo"/>
                        <p>VBK CONSULTANCY</p>
                    </div>
                </Link>
                <div className="P-feature">
                    <h2>Feature Links</h2>
                    <ul>
                        {list1.map((elem, index) => {
                            return <li key={index}><Link to={elem.path}>{elem.description}</Link></li>
                        })}
                    </ul>
                </div>
                <div className="P-support">
                    <h2>Support</h2>
                    <ul>
                        {list2.map((elem, index) => {
                            return <li key={index}><Link to={elem.path}>{elem.description}</Link></li>
                        })}
                    </ul>
                </div>
                <div className="P-footer-contact">
                    <h2>Contact Us</h2>
                    <ul>
                        <li><img src={Tel} alt="tel"/>+971509134617</li>
                        <li><img src={Massage} alt="massage"/>info@vbkc.in</li>
                        <li><img src={Massage} alt="massage"/>Mariia@vbkc.in</li>
                        <ul className="G-flex G-justify-between G-align-center">
                            <li>
                                <div className="P-instagram"/>
                            </li>
                            <li>
                                <div className="P-fb"/>
                            </li>
                            <li>
                                <div className="P-youtube"/>
                            </li>
                            <li>
                                <div className="P-watsapp"/>
                            </li>
                        </ul>
                    </ul>
                </div>
            </div>
        </div>
        <div className="P-footer-mobile">
            <Link to={ROUTER_NAMES.HOME}>
                <div className="P-footer-logo-mobile">
                    <img src={LogoFooter} alt="Logo"/>
                    <p>CONSULTANCY</p>
                </div>
            </Link>
            <ul className="G-flex G-justify-center G-align-center">
                <li>
                    <div className="P-instagram"/>
                </li>
                <li>
                    <div className="P-fb"/>
                </li>
                <li>
                    <div className="P-youtube"/>
                </li>
                <li>
                    <div className="P-watsapp"/>
                </li>
            </ul>
            <div className="P-menu-mobile-main G-flex G-justify-between G-align-center">
                <ul>
                    <li><Link to={ROUTER_NAMES.HOME}>Home</Link></li>
                    <li><Link to={ROUTER_NAMES.ABOUT_US}>About Us</Link></li>
                </ul>
                <ul className="P-menu-center">
                    <li><Link to={ROUTER_NAMES.PRIVACY}>Privacy</Link></li>
                    <li><Link to={ROUTER_NAMES.FAQS}>FAQ</Link></li>
                </ul>
                <ul>
                    <li><Link to={ROUTER_NAMES.NEWS}>News</Link></li>
                    <li><Link to={ROUTER_NAMES.TERMS}>Terms</Link></li>
                </ul>
            </div>
            <div className="P-footer-m-contact G-flex G-justify-center">
                <Link to={ROUTER_NAMES.CONTACT_US}>Contact Us</Link>
            </div>
            <ul className="P-contact-info-m G-flex G-justify-between G-align-center">
                <li className="G-flex G-justify-between G-align-center"><img src={Tel} alt="tel"/>+971509134617</li>
                <li className="G-flex G-justify-between G-align-center"><img src={Massage} alt="massage"/>maria@vbkc.in</li>
            </ul>
        </div>
        <div className="P-footer-reserved G-flex G-center">
            <p>© VBK Consultancy 2022. All rights reserved.</p>
        </div>
    </div>


}

export default Footer