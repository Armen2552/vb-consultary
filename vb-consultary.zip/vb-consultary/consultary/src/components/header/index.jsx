import React, {useEffect, useState} from "react";
import "./style.scss"
import headerLogo from "../../assets/images/logo.svg";
import SignIn from "../pop-up/pop-up-main";
import {SignUp} from "../pop-up/sign-up";
import Burger from "../../assets/images/burger.png"
import BurgerX from "../../assets/images/MenuX.png"
import {NavLink, useLocation, Link} from "react-router-dom";
import {ApiUrl, ROUTER_NAMES} from "../../routers";
import {useGlobalContext} from '../../context';
// import People from '../../assets/images/people.svg'
import {Cookie} from "../Cookie";
import {UserInfo} from "../../platform/api";


const Header = () => {

    // const [search,setSearch] = useState(true)
    const [menuOpen, setMenuOpen] = useState(false)
    const [signIn, setSignIn] = useState(false)
    const [signUp, setSignUp] = useState(false)
    const {cookie, setCookie} = useGlobalContext()
    const location = useLocation()
    const {token, setToken, seeImage,setSeeImage,setProfile, profile} = useGlobalContext()


    // const navigate = useNavigate()
    //
    // const clickbutton = ()=>{
    //
    //     navigate()
    // }


    const [menu] = useState([
        {
            title: 'About Us',
            path: '/about-us'
        },
        {
            title: 'Vacancies',
            path: '/vacancies'
        },
        {
            title: 'Contact Us',
            path: '/contact-us'
        },
    ])


    const [vacancies] = useState([
        {
            title: 'Poland',
            path: '/poland'
        },
        {
            title: 'CzechRepublic',
            path: '/czech-republic'
        },
        {
            title: 'UAE',
            path: '/uae'
        },
        {
            title: 'Russia',
            path: '/russia'
        },
        {
            title: 'Romania',
            path: '/romania'
        }
    ])


    useEffect(() => {
        if (signIn || signUp) {
            document.body.style.overflowY = "hidden"
        } else {
            document.body.style.overflowY = "scroll"
        }
    }, [signUp, signIn])


    useEffect(() => {
        let x = localStorage.getItem('id')
        if (x) {
            setToken(x)
            UserInfoGetHeader(x)
        }
        if (localStorage.getItem("cookie") !== undefined && localStorage.getItem("cookie") !== null) {
            setCookie(localStorage.getItem(+"cookie"))
        }
    }, [])


    const clickCookie = () => {
        localStorage.setItem("cookie", "false")
        setCookie(false)
    }

    const ClickOpenMobile = (e) => {
        setMenuOpen(e)
    }

    const UserInfoGetHeader = async (userId)=>{
        const result = await UserInfo({id:userId})
        if(result){
            setProfile(result.data)
            if(result.data.imagePath) {
                setSeeImage(ApiUrl+result.data.imagePath.slice(6))
            }
        }
    }

    // const clickSearch = ()=>{
    //     setSearch(!search)
    // }


    const closeRegistration = (a) => {
        setSignIn(a)
        setSignUp(a)
    }

    const openRegistration = () => {
        setSignIn(true)
    }

    const openSignUp = () => {
        setSignUp(true)
    }


    return <header>
        <div className="G-container G-flex G-justify-between G-align-center">
            <div className="P-header-menu">
                <Link to={ROUTER_NAMES.HOME}>
                    <div className="P-header-logo">
                        <img src={headerLogo} alt="Logo"/>
                        <p>VBK CONSULTANCY</p>
                    </div>
                </Link>
                <ul>
                    {menu.map((elem, index) => {
                        return <li key={index} className={elem.title === 'Vacancies' ? "P-vacancies-pop" : null}>
                            <NavLink className={`${location.pathname === elem.path ? 'P-active-link' : ''}`}
                                     to={elem.path}>{elem.title}</NavLink>
                            {elem.title === 'Vacancies' ? <span/> : null}
                            {elem.title === 'Vacancies' ? <ul className="G-flex G-flex-column G-justify-center">
                                {vacancies.map((elem, index) => {
                                    return <li key={index}><Link to={elem.path}>{elem.title}</Link></li>
                                })}
                            </ul> : null}
                        </li>
                    })}
                </ul>
                <span/>
                {/*{search? <i className="icon-search P-search" onClick={clickSearch}/> : <input placeholder="Search" type="search"/>}*/}
            </div>
            {token ? <Link to={ROUTER_NAMES.PROFILE}>
                    <img src={seeImage} alt="people"/>
                    <p>{profile.firstName}</p>
                </Link>
                :
                <div className="P-header-buttons G-flex">
                    <button onClick={openSignUp} className='G-button'>Sign In</button>
                    <button onClick={openRegistration} className='G-button P-header-sign-in'>Sign Up</button>
                </div>}
            <div className="P-header-burger" onClick={() => ClickOpenMobile(true)}>
                <img src={Burger} alt="menu-burger"/>
            </div>
            {menuOpen ? <div className="P-header-menu-mobile">
                <div className="G-flex G-justify-end" onClick={() => ClickOpenMobile(false)}>
                    <img src={BurgerX} alt="X"/>
                </div>
                <ul>
                    <li><NavLink
                        className={`P-menu-mobile-bold ${location.pathname === ROUTER_NAMES.ABOUT_US ? 'P-active-link' : ''}`}
                        to={ROUTER_NAMES.ABOUT_US}>About Us</NavLink></li>
                    <li><NavLink
                        className={`P-menu-mobile-bold ${location.pathname === ROUTER_NAMES.VACANCIES ? 'P-active-link' : ''}`}
                        to={ROUTER_NAMES.VACANCIES}>Vacancies</NavLink></li>
                    <li><NavLink className={`${location.pathname === ROUTER_NAMES.POLAND ? 'P-active-link' : ''}`}
                                 to={ROUTER_NAMES.POLAND}>Poland</NavLink></li>
                    <li><NavLink className={`${location.pathname === ROUTER_NAMES.CZEHREPUBLIC ? 'P-active-link' : ''}`}
                                 to={ROUTER_NAMES.CZEHREPUBLIC}>CzehRepublic</NavLink></li>
                    <li><NavLink className={`${location.pathname === ROUTER_NAMES.UAE ? 'P-active-link' : ''}`}
                                 to={ROUTER_NAMES.UAE}>UAE</NavLink></li>
                    <li><NavLink className={`${location.pathname === ROUTER_NAMES.RUSSIA ? 'P-active-link' : ''}`}
                                 to={ROUTER_NAMES.RUSSIA}>Russia</NavLink></li>
                    <li><NavLink className={`${location.pathname === ROUTER_NAMES.ROMANIA ? 'P-active-link' : ''}`}
                                 to={ROUTER_NAMES.ROMANIA}>Romania</NavLink></li>
                    <li><NavLink
                        className={`P-menu-mobile-bold ${location.pathname === ROUTER_NAMES.CONTACT_US ? 'P-active-link' : ''}`}
                        to={ROUTER_NAMES.CONTACT_US}>Contact Us</NavLink></li>
                </ul>
                {token ? <Link to={ROUTER_NAMES.PROFILE}>
                        <img src={seeImage} alt="people"/>
                        <p>{profile.firstName}</p>
                </Link> :
                    <div className="P-header-buttons-mobile G-flex G-flex-column G-align-center">
                        <button onClick={openSignUp} className='G-button'>Sign In</button>
                        <button onClick={openRegistration} className='G-button P-header-sign-in'>Sign Up</button>
                    </div>}
            </div> : null}
            {signIn ? <SignIn close={closeRegistration}/> : null}
            {signUp ? <SignUp close={closeRegistration}/> : null}
        </div>
        {cookie ? <Cookie closeCookie={clickCookie}/> : null}
    </header>
}

export default Header