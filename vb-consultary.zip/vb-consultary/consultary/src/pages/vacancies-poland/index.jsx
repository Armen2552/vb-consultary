import React from "react";
import {PageCover} from "../../components/page-cover";
import Cover1 from "../../assets/images/polandCover.jpg"
import Header from "../../components/header";
import Footer from "../../components/footer";
import PolandGet from "../../assets/images/polandget.jpg"
import './style.scss'


export const Poland = ()=>{


    return <>
        <Header />
        <div className="P-poland">
            <PageCover image={Cover1}  title={"Poland"}/>
            <div className="P-poland-main">
                <p>For legal employment in Poland in most cases it is necessary to obtain “zezwolenie na prace dla cudzoziemca” (hereinafter, the Work Permit in Poland). This is a document confirming the decision of the Voivodeship on the admission of a foreigner to work. How to apply for a work permit in Poland quickly and without hassle? How and where to draw up a document? This will be easy with our company.</p>
                <h2>Why do you need a Poland work permit?</h2>
                <p>Some foreigners mistakenly believe that obtaining a visa is sufficient for legal employment in Poland. This is a big mistake! Visa – permits entry to carry out activities in accordance with which it is issued. A work visa is one of the reasons for obtaining Poland Work Permit (zezwolenie na prace od wojewody), but not its replacement!</p>
                <h2>A work permit in Poland for foreigners can be obtained by persons who have:</h2>
                <h3>Some foreigners mistakenly believe that obtaining a visa is sufficient for legal employment in Poland. This is a big mistake! Visa – permits entry to carry out activities in accordance with which it is issued. A work visa is one of the reasons for obtaining Poland Work Permit (zezwolenie na prace od wojewody), but not its replacement!</h3>
                <h3>Schengen issued by another country in the zone.</h3>
                <h3>Possessing a residence permit (with the exception of cases described in the following section).</h3>
                <h3>The right of visa-free entry, implying the possibility of employment in accordance with an interstate agreement.</h3>
                <h3>Poland Image Second</h3>
                <img src={PolandGet} alt="Poland"/>
                <h2>Information about Poland work permit</h2>
                <p>A work permit is a document that authorizes a foreigner to work legally in Poland. The permit indicates the company that entrusts the execution of work to the foreigner and the position or the type of work which the foreigner is to perform. The work is therefore regarded as legal only if the foreigner performs the work identified in the permit. This means that if the foreigner wants to change jobs (i.e. change employer and / or position and / or industry) in which he is employed, he has to obtain a new permit. However, there are some circumstances in which the permit remains valid despite a change in the circumstances for which it has been issued.</p>
                <h2>1 Year Poland work permit</h2>
                <p>Embassy will be issue you a “one year “Visa Type  D / multiple entry, and its renewable further each year or applicable to apply PR with some reasonable bases.</p>
                <h2>Poland work permit package</h2>
                <h3>Duration of stay 365/365</h3>
                <h3>Expert consultation of visa specialists, assessment of the chances of obtaining a visa</h3>
                <h3>Recommendations on the qualitative preparation of documents, filling in and printing out the questionnaire</h3>
                <h3>The official invitation of the host country, certified by the Polish voivode</h3>
                <h3>Instruction, verification and formation of the full package of documents</h3>
                <h2>Required documents from applicants</h2>
                <h4>1. Passport scan Copy</h4>
                <h4>2. Photo 35mm * 45mm 80% Clear face with white Background</h4>
                <h4>3. If available send your Degree & Experience Certificate for best Placement</h4>
                <h4>4. Email id</h4>
                <h4>5. Contact No</h4>
                <h4>6. Permanent Residence Address</h4>
                <h4>7. Postal Address</h4>
                <h2>What delivery methods we use?</h2>
                <p>We use different delivery methods, depending on the shipping destination of your package and urgency.Aramex is our preferred carrier, but you may also choose Federal Express (FedEx), DHL Express (DHL) or United Parcel Service (UPS). Expedited shipping options are also available for rush deliveries. Before shipping we will send you scanned copies of all documents by email. Tracking code will be provided.</p>
                <h2>What payment methods do we accept?</h2>
                <p>We accept payment via Bank Transfer , Credit Card , PayPal , 2Checkout. Payment accepted only in the name of VB TECHNO SOLUTIONS LLC.</p>
                <h2>Process time</h2>
                <h5>1-1,5 month</h5>
                <p>For more information on open vacancies, please call +971 50 913 4617 (WhatsApp) or mail to info@vbkc.in</p>
            </div>
        </div>
        <Footer />
    </>
}