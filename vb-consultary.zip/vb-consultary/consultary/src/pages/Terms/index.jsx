import React from "react";
import "./style.scss"
import Header from "../../components/header";
import Footer from "../../components/footer";


export const Terms = ()=>{

    return <>
        <Header />
        <div className="P-terms-main">
            <h2>Terms of Use</h2>
            <div className="P-terms-content">
                <div className="P-changes">
                    <h3>Changes to this Site or these Terms</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Faucibus neque sit sed
                        aliquet lectus lorem gravida tristique risus. Auctor augue auctor pretium lectus ac.
                        Eget eget eleifend lacus sagittis aliquam eu et massa, augue. Tortor in sem sit dictum
                        velit scelerisque scelerisque sit. Tortor, nunc tellus scelerisque congue.
                        Integer eget fusce mattis tempus pulvinar. Dolor arcu, dolor curabitur turpis risus
                        porttitor tincidunt faucibus. Amet pellentesque libero commodo, sed velit eget porttitor.
                        Ullamcorper eget ullamcorper quis mattis pharetra nunc ultrices eu. Sem porttitor massa tellus nec amet.
                        Sit et aliquam velit scelerisque vitae duis pharetra nisi, egestas. Ut egestas tempor, eget tortor
                        aliquam et ut pharetra et. Etiam condimentum euismod amet faucibus suscipit tellus id orci eu.
                        Dui non maecenas adipiscing pretium rutrum odio. A posuere dolor felis mi. Sit commodo orci, mi, ac.
                        Egestas interdum arcu euismod maecenas amet diam. Elit arcu aenean malesuada tincidunt felis
                        congue cursus quam. Sed nulla purus, ipsum scelerisque quis.
                        Laoreet bibendum tempus mi dolor nec quis. Felis, pharetra turpis massa sed interdum eu nam.
                        Non lorem elit hendrerit mauris massa ac.
                    </p>
                </div>
                <div className="P-property">
                    <h3>Intellectual Property</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pretium fermentum blandit tortor
                        curabitur. Tincidunt bibendum eget consequat, diam lacus et. Varius id rhoncus, et sit
                        volutpat. Tortor eu nunc dictum adipiscing faucibus commodo in quam. Eu ultricies egestas
                        tincidunt nunc. Nunc nisi, amet amet, quam volutpat aliquam praesent
                        turpis. <span>www.vkbc.com</span> morbi eget nunc nunc. Libero, risus mi eget fames in tincidunt
                        feugiat velit. Accumsan,
                        auctor ac ultrices sed augue morbi etiam. Morbi vitae eget turpis dictum euismod platea.
                    </p>
                </div>
                <div className="P-terms-registration">
                    <h3>Registration</h3>
                    <p>
                        <span>Lorem ipsum</span> dolor sit amet, consectetur adipisicing elit. Aliquid
                        consequatur labore modi porro quidem, sint? Deserunt esse maxime
                        mollitia nulla qui, quod recusandae? Dignissimos dolor nesciunt obcaecati optio
                        repellendus totam?
                    </p>
                    <p>
                        <span>Lorem ipsum</span> dolor sit amet, consectetur adipisicing elit. Aliquid
                        consequatur labore modi porro quidem, sint? Deserunt esse maxime
                        mollitia nulla qui, quod recusandae? Dignissimos dolor nesciunt obcaecati optio
                        repellendus totam?
                    </p>
                    <p>
                        <span>Lorem ipsum</span> dolor sit amet, consectetur adipisicing elit. Aliquid
                        consequatur labore modi porro quidem, sint? Deserunt esse maxime
                        mollitia nulla qui, quod recusandae? Dignissimos dolor nesciunt obcaecati optio
                        repellendus totam?
                    </p>
                </div>
            </div>
        </div>
        <Footer />
    </>
}