import React, {useEffect, useState} from "react";
import Header from "../../components/header";
import Footer from "../../components/footer";
import "./style.scss"
import {Link} from "react-router-dom"
import LatestCover1 from "../../assets/images/News1.jpg";
import LatestCover2 from "../../assets/images/News2.png";
import LatestCover3 from "../../assets/images/News3.jpg";
import {ApiUrl, ROUTER_NAMES} from "../../routers";
import {useGlobalContext} from "../../context";
import {GetNews} from "../../platform/api";


export const News = () => {
    const {setNewSub,news,setNews} = useGlobalContext()

    const [newsInfo] = useState([
        {
            img: LatestCover1,
            description: 'How to Learn Faster and Remember',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '6 June 2022'
        },
        {
            img: LatestCover2,
            description: 'Free Online Courses from Top Universities',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '25 May 2022'
        },
        {
            img: LatestCover3,
            description: 'Learn Exactly How I Improved Education',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '20 May 2022'
        },
        {
            img: LatestCover1,
            description: 'How to Learn Faster and Remember',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '6 June 2022'
        },
        {
            img: LatestCover2,
            description: 'Free Online Courses from Top Universities',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '25 May 2022'
        },
        {
            img: LatestCover3,
            description: 'Learn Exactly How I Improved Education',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '20 May 2022'
        },
        {
            img: LatestCover1,
            description: 'How to Learn Faster and Remember',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '6 June 2022'
        },
        {
            img: LatestCover2,
            description: 'Free Online Courses from Top Universities',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '25 May 2022'
        },
        {
            img: LatestCover3,
            description: 'Learn Exactly How I Improved Education',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '20 May 2022'
        },
        {
            img: LatestCover1,
            description: 'How to Learn Faster and Remember',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '6 June 2022'
        },
        {
            img: LatestCover2,
            description: 'Free Online Courses from Top Universities',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '25 May 2022'
        },
        {
            img: LatestCover3,
            description: 'Learn Exactly How I Improved Education',
            title: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do',
            date: '20 May 2022'
        }
    ])

    useEffect(()=>{
        GetInfoNews()
    },[])

    const clickNews = (e)=>{
        setNewSub(newsInfo[e])
    }

    const GetInfoNews = async ()=>{
        const result = await GetNews()
        if(result.data){
            setNews(result.data)
            console.log(news)
        }else{
            console.log("error")
        }
    }


    return <>
        <Header/>
        <section>
            <div className="P-news-cover G-flex G-align-center">
                <div className="G-container">
                    <p>VBK NEWS</p>
                </div>
            </div>
            <div className="G-container G-flex G-justify-between G-flex-wrap">
                {news.map((elem, index) => {
                    return <div key={index} className="P-news-box G-flex G-flex-column">
                        <img src={ApiUrl + elem.img.slice(6)} alt="Cover-News"/>
                        <div className="P-news-info G-flex G-align-start G-justify-between">
                            <p className="P-news-date">{elem.create_at.toString().slice(0, 10)}</p>
                            <div className="P-news-title G-flex G-flex-column">
                                <h2>{elem.description}</h2>
                                <p>{elem.title}</p>
                                <Link to={ROUTER_NAMES.NEWS_SUB}>
                                    <button onClick={()=>clickNews(index)}>READ MORE</button>
                                </Link>
                            </div>
                        </div>
                    </div>
                })}
            </div>
        </section>
        <Footer/>
    </>
}