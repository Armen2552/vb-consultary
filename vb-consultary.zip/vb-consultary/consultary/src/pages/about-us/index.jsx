import React from "react";
import "./style.scss"
import {AboutContent} from "../../components/about-content";
import Cover1 from "../../assets/images/about-cover1.jpg"
import Cover2 from "../../assets/images/about-cover2.jpg"
import Cover3 from "../../assets/images/about-cover3.jpg"
import Cover4 from "../../assets/images/about-cover4.jpg"
import Cover5 from "../../assets/images/Abm4.jpg"
import Cover6 from "../../assets/images/Abm3.jpg"
import Cover7 from "../../assets/images/Abm2.jpg"
import Cover8 from "../../assets/images/Abm1.jpg"
import Header from "../../components/header";
import Footer from "../../components/footer";

export const About = () => {


    return <>
        <Header/>
        <div className="P-about">
            <AboutContent
                image1={Cover1}
                image11={Cover5}
                title1={"WHO WE ARE"}
                description1={"We lead the way in recruiting with our effective staffing solutions.We are licensed company providing HR service in countries where we operate and carry out business of\n" +
                "Hiring and Recruitment of personnel for different kind of projects either individually or with effective\n" +
                "JV’s and partnerships with local industry leaders serving major Oil & Gas / Agriculture/ Manufacture/\n" +
                "Construction/ Hospitality fields."}
                image2={Cover2}
                image21={Cover6}
                title2={"WHAT WE DO"}
                description2={"VBK Consultancy is passionate about listening to our clients and providing HR services which meets your\n" +
                "HR needs and prepare you for growth while protecting your business.We work with businesses of all sizes whatever your budget. Our HR Company is comprised of a friendly\n" +
                "team of qualified HR experts who have real business experience and will never use scripts or sit on the\n" +
                "fence when advising you."}
            />
            <AboutContent
                image1={Cover3}
                image11={Cover7}
                title1={"OUR MISSION"}
                description1={"- To be a company that inspires workers and fulfills their aspirations.\n" +
                "- To attract and attain clients with excellent service, professionalism, competence and integrity as\n" +
                "the benchmark of our performance."}
                image2={Cover4}
                image21={Cover8}
                title2={"OUR VISION"}
                description2={"VBK Consultancy works relentlessly to be the leading global manpower recruitment agency, delivering\n" +
                "exceptional service by providing reliable and highly equipped workforce anywhere in the world."}
            />
        </div>
        <Footer/>
    </>
}