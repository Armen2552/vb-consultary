import React, {useState} from "react";
import {PageCover} from "../../components/page-cover";
import ContactCover from "../../assets/images/contactCover.jpg"
import "./style.scss"
import Header from "../../components/header";
import Footer from "../../components/footer";
import Point from "../../assets/images/ponit.png"
import Massage from "../../assets/images/massageBlack.png"
import Tel from "../../assets/images/telBlack.png"
import Browser from "../../assets/images/browserBlack.png"
import {ContactTake} from "../../platform/api";
import {isEmail} from "../../utils/utils";


export const Contact = () => {
    const [sendMassage, setSendMassage] = useState({
        email: "",
        massage: ""
    })
    const [errors, setErrors] = useState({
        email: "",
        massage: ""
    })

    const validation = () => {
        let isValidate = true
        const errors = {
            email: '',
            massage: ""
        }

        if (!sendMassage.email.trim().length) {
            isValidate = false
            errors.email = 'Fill the first name field'
        } else if (sendMassage.email && !isEmail(sendMassage.email)) {
            isValidate = false
            errors.email = 'Incorrect email address'
        }
        if (!sendMassage.massage.trim().length) {
            isValidate = false
            errors.massage = 'Fill the first name field'
        }

        setErrors(errors)
        return isValidate
    }


    const checkChange = (e) => {
        setSendMassage({...sendMassage, [e.target.name]: e.target.value})
        setErrors({...errors, [e.target.name]: ''})
    }

    // const GiveContact = async () => {
    //     if (validation()) {
    //         const result = await Contact(sendMassage)
    //         if (result) {
    //             console.log("access")
    //         } else {
    //             console.log("error")
    //         }
    //     }
    // }

    const GiveContact = async () => {
        if (validation()) {
            console.log(sendMassage)
            const result = await ContactTake(sendMassage)
            if (result) {
                console.log("accept")
                setSendMassage({...sendMassage, massage: "", email: ""})
            }
        }
    }


    return <>
        {console.log(sendMassage)}
        <Header/>
        <div className="P-contact">
            <PageCover image={ContactCover} title={"Contact Us"}/>
            <div className="P-contact-main G-flex G-justify-around">
                <div className="P-contact-keep">
                    <h3>Contact us</h3>
                    <span/>
                    <h2>Keep in Touch</h2>
                    <label>
                        <input
                            value={sendMassage.email}
                            placeholder="Your Email" type="email" name="email" onChange={checkChange}
                            className={errors.email ? "P-error" : null}
                        />
                    </label>
                    <textarea
                        value={sendMassage.massage}
                        placeholder="Your Massage"
                        name="massage"
                        cols="30"
                        rows="10"
                        onChange={checkChange}
                        className={errors.massage ? "P-error" : null}
                    />
                    <button className="G-button" onClick={GiveContact}>Submit</button>
                </div>
                <div className="P-contact-address">
                    <h3>Address</h3>
                    <span/>
                    <div className="P-contact-icons">
                        <div className="P-contact-icon">
                            <div className="G-flex G-align-center G-justify-between">
                                <img src={Massage} alt="icon"/>
                                <p>Mariia@vbkc.in</p>
                            </div>
                            <span/>
                        </div>
                        <div className="P-contact-icon">
                            <div className="G-flex G-align-center G-justify-between">
                                <img src={Tel} alt="icon"/>
                                <p>+971509134617</p>
                            </div>
                            <span/>
                        </div>
                        <div className="P-contact-icon">
                            <div className="G-flex G-align-center G-justify-between">
                                <img src={Browser} alt="icon"/>
                                <p>vbkconsultancy.in</p>
                            </div>
                            <span/>
                        </div>
                        <div className="P-contact-icon">
                            <div className="G-flex G-align-center G-justify-between">
                                <img src={Point} alt="icon"/>
                                <p>Dubai Silicon Oasis, DDP, Building A1, Dubai United Arab Emirates</p>
                            </div>
                            <span/>
                        </div>
                    </div>
                    <div className="P-map">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3730.098386658121!2d55.375305250566115!3d25.11865084096791!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f6580a2b2d27d%3A0x4aea6ca8a0d4beff!2sA1%20building!5e1!3m2!1sen!2s!4v1666861121723!5m2!1sen!2s"
                            title={'iframe'} width={'100%'} style={{border: 0}} allowFullScreen={true} loading={'lazy'}
                            referrerPolicy="no-referrer-when-downgrade"/>
                    </div>
                </div>
            </div>
        </div>
        <Footer/>
    </>
}