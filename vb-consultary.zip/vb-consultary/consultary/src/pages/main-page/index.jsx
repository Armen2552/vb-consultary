import React, {useEffect, useState} from "react";
import "./style.scss";
import Welcome from "../../components/Section-welcome";
import Video from "../../components/Video-cover";
import LatestNews from "../../components/Section-lates-news";
import {useGlobalContext} from "../../context";
import {useNavigate} from "react-router-dom"
import {ROUTER_NAMES} from "../../routers";
import SignIn from "../../components/pop-up/pop-up-main";


const Main = ()=>{
    // const profile  = useSelector(state =>state.profile)
    const navigate = useNavigate()
    const {token} = useGlobalContext()
    const [signIn, setSignIn] = useState(false)

    useEffect(() => {
        if (signIn) {
            document.body.style.overflowY = "hidden"
        } else {
            document.body.style.overflowY = "scroll"
        }
    }, [signIn])

    const OpenApply = ()=>{
        if(token){
            navigate(ROUTER_NAMES.APPLY)
        }else{
            setSignIn(true)
        }
    }

    const closeRegistration = (a) => {
        setSignIn(a)
    }




    return <section>
            <div className="P-section-main">
                <div className="G-container">
                    <div className="P-section-main-title">
                        <h2><span> LET’S</span> TALK ABOUT HOW WE COULD<span> WORK TOGETHER</span></h2>
                        <p>
                            Join us and you’ll be able to build a more varied and rewarding career - whether you are a new graduate
                            or an experienced professional - in a supportive environment founded on our values of commitment,
                            teamwork and excellence.
                        </p>
                        <button onClick={OpenApply} className="G-button">Apply Now</button>
                    </div>
                </div>
            </div>
            <Welcome />
            <Video />
            <LatestNews />
            {signIn ? <SignIn close={closeRegistration}/> : null}
        </section>
}



export default Main