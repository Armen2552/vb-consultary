import React, {useState} from "react";
import "./style.scss"
import Header from "../../components/header";
import Footer from "../../components/footer";
// import {useGlobalContext} from "../../context";
import LatestCover1 from "../../assets/images/NewsSub.jpg";

export const NewsSub = () => {
    // const {newsSub} = useGlobalContext()

    const [newsInfo] = useState({
            img: LatestCover1,
            description: 'How to Learn Faster and Remember',
            title: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet blanditiis consequuntur corporis culpa doloremque ea esse est, eveniet hic illo iste itaque labore natus, neque nulla numquam omnis pariatur praesentium quaerat quam, quod recusandae similique sunt temporibus vel velit voluptate. Aperiam aut beatae commodi, distinctio doloremque dolores illo iste iusto labore laboriosam magni molestias neque officia possimus quibusdam saepe similique suscipit tempore unde vitae. Nemo neque odio vitae! Aliquam amet assumenda corporis dolorem, dolores eum in inventore molestiae nobis optio placeat quo rerum sint vero vitae! Aspernatur assumenda atque beatae corporis debitis dolore dolorem, eligendi id minus natus nulla optio quos sequi soluta voluptates. Atque beatae consectetur cumque dicta, dolores expedita fuga inventore iste magnam nemo nihil perferendis provident quae quia reprehenderit, repudiandae sapiente velit vero? A, atque culpa error neque omnis quam! Aperiam aspernatur, autem dolor eos expedita facere harum itaque neque nihil nostrum pariatur porro quasi, rem temporibus, totam! A aperiam, error et ex ipsa nobis qui quia quis quod, recusandae repellendus vel veniam. Ad atque debitis, dolores dolorum eaque, eligendi enim esse ex inventore iste itaque laborum nam quaerat quod rem sit totam ullam veniam voluptas voluptatem? Aliquid asperiores at autem cum distinctio dolor dolore eaque excepturi exercitationem illum, impedit ipsam minus, mollitia nam nobis obcaecati omnis perspiciatis quam quasi quis quo reiciendis repellendus repudiandae saepe sequi totam velit veritatis voluptatem voluptatibus voluptatum? Animi eaque, eos fuga labore nostrum optio soluta suscipit voluptatem? Animi assumenda at dolore dolorem earum esse est fugiat incidunt ipsam iste, molestiae mollitia nam optio quam quas quibusdam vitae? Aliquam autem culpa cupiditate, deserunt dignissimos explicabo facilis modi numquam odit quasi recusandae sunt temporibus voluptates. Earum labore non rem. Alias architecto aspernatur atque beatae consequatur cupiditate deserunt ducimus eos est eum, itaque labore magnam maiores minima nam nisi nobis, optio possimus repellendus saepe sapiente temporibus ut veritatis voluptas voluptates! Aperiam architecto at atque cumque distinctio, ea eos esse harum inventore labore, maiores modi pariatur perspiciatis praesentium quia quidem quo recusandae repudiandae sunt suscipit? At, consequatur corporis eligendi excepturi ipsam officia quos repellendus velit. Accusantium architecto commodi distinctio molestias perspiciatis quo tenetur vitae voluptate? Accusamus animi culpa dolorem esse id illo, illum, magnam, nihil nisi non odio quidem quo temporibus veritatis vitae. Aliquam animi asperiores blanditiis deserunt, dolor dolores doloribus et harum, laudantium nemo neque obcaecati odit placeat quod temporibus tenetur voluptas voluptatem voluptatibus. Ab, alias amet animi assumenda beatae consectetur culpa dolor dolore, doloribus expedita fugiat illum in ipsam ipsum iste iure magnam molestias nam nesciunt nisi porro quaerat quia quos reprehenderit repudiandae rerum, sequi sint suscipit tempore tenetur veniam vero vitae voluptate. Alias architecto assumenda autem odit perferendis placeat suscipit ut. Consequuntur dolore dolores earum eveniet ex facere harum itaque, mollitia nam non nulla placeat recusandae rem sint temporibus ut, vitae. Architecto atque blanditiis consequuntur corporis deleniti deserunt dolore dolorem doloremque dolores ducimus earum eligendi est eum facere hic illo impedit iusto modi neque nostrum numquam possimus, provident quaerat quasi quibusdam quidem quis quo recusandae repellendus reprehenderit repudiandae temporibus veniam voluptatum. Aperiam.",
            date: '6 June 2022'
        }
    )


    return <>
        <Header/>
        <div className="P-news-sub">
            <div className="G-container">
                <span>{newsInfo.date}</span>
                <h2>{newsInfo.description}</h2>
                <img src={newsInfo.img} alt="News-cover"/>
                <p>{newsInfo.title}</p>
            </div>
        </div>
        <Footer/>

    </>
}