import React from "react";
import {HelpContent} from "../../components/help-center-content";
import './style.scss'
import {Link} from "react-router-dom";
import {ROUTER_NAMES} from "../../routers";
import Header from "../../components/header";
import Footer from "../../components/footer";


export const Help = () => {


    return <>
        <Header/>
        <div className="P-help">
            <div className="P-help-title">
                <h2>HELP CENTER</h2>
                <h3>Frequently asked questions</h3>
            </div>
            <div className="P-help-section G-flex G-flex-wrap G-justify-between G-align-start">
                <div>
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                </div>
                <div>
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                    <HelpContent
                        description={"Why is VBK Consultancy better than Product X?"}
                        description2={"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto autem commodi dicta esse est in laborum magni porro reiciendis totam!"}
                    />
                </div>
            </div>
            <div className="P-still-question">
                <h4>Still have a question?</h4>
                <p>If you cannot find answer to your question in our FAQ, you can always <Link
                    to={ROUTER_NAMES.CONTACT_US}>contact us</Link></p>
            </div>
        </div>
        <Footer/>
    </>
}