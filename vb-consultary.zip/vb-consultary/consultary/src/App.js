import React, {useEffect} from "react";
import {Route, Routes} from "react-router-dom";
// import {Poland} from "./pages/vacancies-poland";
import AppComponent from "./components/app-component";
// import AdminPages from "./components/admin-pages";
import {ROUTER_NAMES} from "./routers";
import {About} from "./pages/about-us";
import {Contact} from "./pages/contact-us";
import {Privacy} from "./pages/Privacy";
import {Help} from "./pages/Help-center";
import {Terms} from "./pages/Terms";
import {Profile} from "./components/Profile";
import {Poland} from "./pages/vacancies-poland";
import {useLocation} from 'react-router-dom'
import {News} from "./pages/News";
import {NewsSub} from "./pages/News-sub";


function App() {
    const {pathname} = useLocation()
    useEffect(() => {
        window.scrollTo(0, 0)
    }, [pathname])
    return (<div className="App">
            {/*<AppComponent/>*/}
            <Routes>
                <Route path={ROUTER_NAMES.PROFILE} element={<Profile/>}/>
                <Route path={ROUTER_NAMES.APPLY} element={<Profile/>}/>
                <Route path={ROUTER_NAMES.HOME} element={<AppComponent/>}/>
                <Route path={ROUTER_NAMES.ABOUT_US} element={<About/>}/>
                <Route path={ROUTER_NAMES.CONTACT_US} element={<Contact/>}/>
                <Route path={ROUTER_NAMES.PRIVACY} element={<Privacy/>}/>
                <Route path={ROUTER_NAMES.FAQS} element={<Help/>}/>
                <Route path={ROUTER_NAMES.TERMS} element={<Terms/>}/>
                <Route path={ROUTER_NAMES.POLAND} element={<Poland/>}/>
                <Route path={ROUTER_NAMES.NEWS} element={<News/>}/>
                <Route path={ROUTER_NAMES.NEWS_SUB} element={<NewsSub/>}/>
                <Route path="*" element={<AppComponent/>}/>
            </Routes>
            {/*<Poland />*/}
            {/*<Profile />*/}
        </div>
    );
}

export default App;
