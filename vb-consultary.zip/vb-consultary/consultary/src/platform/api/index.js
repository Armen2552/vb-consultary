import axios from "axios";
import {ApiUrl} from "../../routers";


export const RegistrationUser = async (data)=>{
    return await axios.post(`${ApiUrl}userRegister`, data)
}
export const UserInfo = async (data)=>{
    return await axios.post(`${ApiUrl}send_info_to_apply`, data)
}
export const UserInfoAll = async (data)=>{
    return await axios.post(`${ApiUrl}apply_user_all_info`, data)
}

export const UserImage = async (form_data)=>{
    return await axios.post(`${ApiUrl}upload_image`,form_data)
}

export const UserResume = async (form_data)=>{
    return await axios.post(`${ApiUrl}upload_resume`,form_data)
}
export const RegistrationCompany = async (data)=>{
    return await axios.post(`${ApiUrl}companyRegister`, data)
}

export const RegisterSignUp = async (data)=>{
    return await axios.post(`${ApiUrl}signUp`, data)
}

export const ForgotPassword = async (data)=>{
    return await axios.post(`${ApiUrl}restorePassword`, data)
}

export const ContactTake = async (data)=>{
    return await axios.post(`${ApiUrl}contactus`, data)
}

export const DeactiveAccount = async (data)=>{
    return await axios.post(`${ApiUrl}deactivate_account`, data)
}

export const GetNews = async (data)=>{
    return await axios.get(`${ApiUrl}send_news`, data)
}